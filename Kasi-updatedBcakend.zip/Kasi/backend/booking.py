from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import SessionLocal
from models import Booking
from pydantic import BaseModel

router = APIRouter()

class BookingRequest(BaseModel):
    from_: str
    to: str
    date: str
    seats: int

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/book")
def book(data: BookingRequest, db: Session = Depends(get_db)):
    booking = Booking(
        from_location=data.from_,
        to_location=data.to,
        date=data.date,
        seats=data.seats
    )
    db.add(booking)
    db.commit()
    return {"message": "Booking successful"}