from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import SessionLocal
from models import Payment
from pydantic import BaseModel

router = APIRouter()

class PaymentRequest(BaseModel):
    card_number: str
    expiry: str
    cvv: str
    name: str

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/pay")
def pay(data: PaymentRequest, db: Session = Depends(get_db)):
    payment = Payment(
        card_number=data.card_number,
        expiry=data.expiry,
        cvv=data.cvv,
        name=data.name
    )
    db.add(payment)
    db.commit()
    return {"message": "Payment processed"}