document.addEventListener('DOMContentLoaded', () => {
    loadPaymentDetails();
    setupEventListeners();
});

let paymentDetails = null;

function setupEventListeners() {
    // Payment method selection
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', handlePaymentMethodChange);
    });

    // Button actions
    document.getElementById('payNowBtn').addEventListener('click', processPayment);
    document.getElementById('cancelBtn').addEventListener('click', cancelPayment);
}

async function loadPaymentDetails() {
    try {
        // Get booking ID from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const bookingId = urlParams.get('bookingId');
        
        if (!bookingId) {
            throw new Error('No booking ID provided');
        }

        // Fetch booking details from API
        const response = await apiRequest(`/bookings/${bookingId}`);
        paymentDetails = response;

        // Update UI with payment details
        updatePaymentUI(paymentDetails);
    } catch (error) {
        showAlert('Failed to load payment details', 'error');
        console.error('Error loading payment details:', error);
    }
}

function updatePaymentUI(details) {
    // Update booking reference
    document.getElementById('bookingReference').textContent = details.bookingReference;

    // Update amounts
    document.getElementById('ticketPrice').textContent = `R${details.ticketPrice.toFixed(2)}`;
    document.getElementById('serviceFee').textContent = `R${details.serviceFee.toFixed(2)}`;
    document.getElementById('totalAmount').textContent = `R${(details.ticketPrice + details.serviceFee).toFixed(2)}`;
}

function handlePaymentMethodChange(event) {
    const method = event.target.value;
    const formContainer = document.getElementById('paymentForm');
    
    // Clear existing form
    formContainer.innerHTML = '';
    
    // Add appropriate form based on selected method
    switch (method) {
        case 'credit-card':
            formContainer.innerHTML = createCreditCardForm();
            break;
        case 'instant-eft':
            formContainer.innerHTML = createEFTForm();
            break;
        case 'mobile-money':
            formContainer.innerHTML = createMobileMoneyForm();
            break;
    }
}

function createCreditCardForm() {
    return `
        <div class="form-group">
            <label for="cardNumber">Card Number</label>
            <input type="text" id="cardNumber" placeholder="1234 5678 9012 3456" maxlength="19">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="expiryDate">Expiry Date</label>
                <input type="text" id="expiryDate" placeholder="MM/YY" maxlength="5">
            </div>
            <div class="form-group">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" placeholder="123" maxlength="3">
            </div>
        </div>
        <div class="form-group">
            <label for="cardName">Name on Card</label>
            <input type="text" id="cardName" placeholder="John Doe">
        </div>
    `;
}

function createEFTForm() {
    return `
        <div class="bank-details">
            <h4>Bank Details</h4>
            <p>Bank: FNB</p>
            <p>Account Name: Kasi Bus</p>
            <p>Account Number: 1234 5678 9012</p>
            <p>Branch Code: 250655</p>
            <p>Reference: ${paymentDetails?.bookingReference || 'Loading...'}</p>
        </div>
    `;
}

function createMobileMoneyForm() {
    return `
        <div class="form-group">
            <label for="mobileNumber">Mobile Number</label>
            <input type="tel" id="mobileNumber" placeholder="+27 12 345 6789">
        </div>
        <div class="form-group">
            <label for="provider">Select Provider</label>
            <select id="provider">
                <option value="">Select Provider</option>
                <option value="vodacom">Vodacom</option>
                <option value="mtn">MTN</option>
                <option value="cellc">Cell C</option>
                <option value="telkom">Telkom</option>
            </select>
        </div>
    `;
}

async function processPayment() {
    try {
        const selectedMethod = document.querySelector('input[name="paymentMethod"]:checked');
        
        if (!selectedMethod) {
            throw new Error('Please select a payment method');
        }

        const paymentMethod = selectedMethod.value;
        let paymentData = {
            bookingId: paymentDetails.bookingId,
            method: paymentMethod,
            amount: paymentDetails.ticketPrice + paymentDetails.serviceFee
        };

        // Add method-specific data
        switch (paymentMethod) {
            case 'credit-card':
                paymentData = {
                    ...paymentData,
                    cardNumber: document.getElementById('cardNumber').value,
                    expiryDate: document.getElementById('expiryDate').value,
                    cvv: document.getElementById('cvv').value,
                    cardName: document.getElementById('cardName').value
                };
                break;
            case 'mobile-money':
                paymentData = {
                    ...paymentData,
                    mobileNumber: document.getElementById('mobileNumber').value,
                    provider: document.getElementById('provider').value
                };
                break;
        }

        // Send payment to API
        const response = await apiRequest('/payments', {
            method: 'POST',
            body: JSON.stringify(paymentData)
        });

        showAlert('Payment processed successfully', 'success');
        
        // Redirect to confirmation page
        window.location.href = `booking-confirmation.html?bookingId=${paymentDetails.bookingId}`;
    } catch (error) {
        showAlert(error.message || 'Payment processing failed', 'error');
        console.error('Payment error:', error);
    }
}

function cancelPayment() {
    if (confirm('Are you sure you want to cancel this payment? Your booking will be cancelled.')) {
        window.location.href = 'booking-history.html';
    }
} 