document.addEventListener('DOMContentLoaded', () => {
    initializePage();
    setupEventListeners();
});

let currentSchedules = [];

function initializePage() {
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('travelDate').min = today;
}

function setupEventListeners() {
    // Search form submission
    document.getElementById('scheduleSearchForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await searchSchedules();
    });

    // Sort and filter changes
    document.getElementById('sortBy').addEventListener('change', sortSchedules);
    document.getElementById('busType').addEventListener('change', filterSchedules);
}

async function searchSchedules() {
    const formData = {
        origin: document.getElementById('origin').value,
        destination: document.getElementById('destination').value,
        travelDate: document.getElementById('travelDate').value,
        passengers: document.getElementById('passengers').value
    };

    try {
        const response = await apiRequest('/schedules/search', {
            method: 'POST',
            body: JSON.stringify(formData)
        });

        if (response) {
            currentSchedules = response.schedules;
            displaySchedules(currentSchedules);
        }
    } catch (error) {
        showAlert('Failed to fetch schedules', 'error');
    }
}

function displaySchedules(schedules) {
    const resultsContainer = document.getElementById('scheduleResults');
    resultsContainer.innerHTML = '';

    if (schedules.length === 0) {
        resultsContainer.innerHTML = `
            <div class="no-results">
                <i class="fas fa-bus"></i>
                <p>No buses available for the selected route and date</p>
            </div>
        `;
        return;
    }

    schedules.forEach(schedule => {
        const card = document.createElement('div');
        card.className = 'schedule-card';
        card.innerHTML = `
            <div class="schedule-header">
                <span class="bus-type ${schedule.busType.toLowerCase()}">${schedule.busType}</span>
                <span class="seats-available">${schedule.availableSeats} seats left</span>
            </div>
            <div class="schedule-details">
                <div class="time-details">
                    <div class="departure">
                        <p class="time">${schedule.departureTime}</p>
                        <p class="city">${schedule.origin}</p>
                    </div>
                    <div class="duration">
                        <i class="fas fa-clock"></i>
                        <p>${schedule.duration}</p>
                    </div>
                    <div class="arrival">
                        <p class="time">${schedule.arrivalTime}</p>
                        <p class="city">${schedule.destination}</p>
                    </div>
                </div>
                <div class="price-section">
                    <p class="price">R${schedule.price}</p>
                    <button onclick="viewBusDetails('${schedule.id}')" class="btn btn-primary">Select</button>
                </div>
            </div>
        `;
        resultsContainer.appendChild(card);
    });
}

function sortSchedules() {
    const sortBy = document.getElementById('sortBy').value;
    const sortedSchedules = [...currentSchedules];

    switch (sortBy) {
        case 'departure':
            sortedSchedules.sort((a, b) => a.departureTime.localeCompare(b.departureTime));
            break;
        case 'duration':
            sortedSchedules.sort((a, b) => a.duration.localeCompare(b.duration));
            break;
        case 'price':
            sortedSchedules.sort((a, b) => a.price - b.price);
            break;
    }

    displaySchedules(sortedSchedules);
}

function filterSchedules() {
    const busType = document.getElementById('busType').value;
    const filteredSchedules = busType 
        ? currentSchedules.filter(schedule => schedule.busType.toLowerCase() === busType)
        : currentSchedules;
    
    displaySchedules(filteredSchedules);
}

async function viewBusDetails(scheduleId) {
    try {
        const response = await apiRequest(`/schedules/${scheduleId}`);
        if (response) {
            const bus = response.bus;
            
            // Display bus information
            document.getElementById('busInfo').innerHTML = `
                <div class="detail-section">
                    <h3>Bus Information</h3>
                    <p><strong>Bus Number:</strong> ${bus.number}</p>
                    <p><strong>Type:</strong> ${bus.type}</p>
                    <p><strong>Total Seats:</strong> ${bus.totalSeats}</p>
                    <p><strong>Available Seats:</strong> ${bus.availableSeats}</p>
                </div>
                <div class="detail-section">
                    <h3>Journey Details</h3>
                    <p><strong>Departure:</strong> ${bus.departureTime} (${bus.origin})</p>
                    <p><strong>Arrival:</strong> ${bus.arrivalTime} (${bus.destination})</p>
                    <p><strong>Duration:</strong> ${bus.duration}</p>
                    <p><strong>Price:</strong> R${bus.price}</p>
                </div>
            `;

            // Display amenities
            document.getElementById('amenities').innerHTML = `
                <h3>Amenities</h3>
                <div class="amenities-list">
                    ${bus.amenities.map(amenity => `
                        <div class="amenity">
                            <i class="fas ${getAmenityIcon(amenity)}"></i>
                            <span>${amenity}</span>
                        </div>
                    `).join('')}
                </div>
            `;

            // Display seat map
            displaySeatMap(bus.seats);

            // Show modal
            document.getElementById('busDetailsModal').style.display = 'block';
        }
    } catch (error) {
        showAlert('Failed to load bus details', 'error');
    }
}

function displaySeatMap(seats) {
    const seatMap = document.getElementById('seatMap');
    seatMap.innerHTML = `
        <h3>Select Your Seat</h3>
        <div class="seat-map">
            ${seats.map(seat => `
                <div class="seat ${seat.status.toLowerCase()}" 
                     data-seat-number="${seat.number}"
                     onclick="selectSeat('${seat.number}')">
                    ${seat.number}
                </div>
            `).join('')}
        </div>
        <div class="seat-legend">
            <div class="legend-item">
                <div class="seat available"></div>
                <span>Available</span>
            </div>
            <div class="legend-item">
                <div class="seat selected"></div>
                <span>Selected</span>
            </div>
            <div class="legend-item">
                <div class="seat occupied"></div>
                <span>Occupied</span>
            </div>
        </div>
    `;
}

function getAmenityIcon(amenity) {
    const icons = {
        'WiFi': 'fa-wifi',
        'AC': 'fa-snowflake',
        'USB Charging': 'fa-plug',
        'Restroom': 'fa-restroom',
        'Entertainment': 'fa-tv',
        'Snacks': 'fa-utensils',
        'Water': 'fa-glass-water',
        'Blanket': 'fa-blanket'
    };
    return icons[amenity] || 'fa-circle-check';
}

function selectSeat(seatNumber) {
    const seat = document.querySelector(`[data-seat-number="${seatNumber}"]`);
    if (seat && !seat.classList.contains('occupied')) {
        seat.classList.toggle('selected');
    }
}

function proceedToBooking() {
    const selectedSeats = Array.from(document.querySelectorAll('.seat.selected'))
        .map(seat => seat.dataset.seatNumber);
    
    if (selectedSeats.length === 0) {
        showAlert('Please select at least one seat', 'error');
        return;
    }

    // Store selected seats in session storage
    sessionStorage.setItem('selectedSeats', JSON.stringify(selectedSeats));
    window.location.href = 'booking.html';
}

// Close modals when clicking outside
window.onclick = (event) => {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }
};

// Close modals when clicking close button
document.querySelectorAll('.close').forEach(closeBtn => {
    closeBtn.onclick = () => {
        closeBtn.closest('.modal').style.display = 'none';
    };
}); 