document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    loadFAQs();
    initializeChat();
});

function setupEventListeners() {
    // FAQ item click handlers
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', toggleFAQ);
    });

    // Category navigation
    document.querySelectorAll('.help-categories a').forEach(link => {
        link.addEventListener('click', handleCategoryClick);
    });

    // Contact form submission
    document.getElementById('contactForm')?.addEventListener('submit', handleContactSubmission);

    // Search functionality
    document.getElementById('helpSearch')?.addEventListener('input', handleSearch);

    // Chat form
    document.getElementById('chatForm')?.addEventListener('submit', handleChatSubmission);
}

async function loadFAQs() {
    try {
        const response = await apiRequest('/faqs');
        displayFAQs(response.faqs);
    } catch (error) {
        showAlert('Failed to load FAQs', 'error');
        console.error('FAQ loading error:', error);
    }
}

function displayFAQs(faqs) {
    const container = document.getElementById('faqContainer');
    if (!container || !faqs?.length) return;

    container.innerHTML = faqs.map(faq => `
        <div class="faq-item" data-category="${faq.category}">
            <div class="faq-question">
                <h3>${faq.question}</h3>
                <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
                <p>${faq.answer}</p>
            </div>
        </div>
    `).join('');

    // Reattach event listeners
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', toggleFAQ);
    });
}

function toggleFAQ(event) {
    const faqItem = event.currentTarget.parentElement;
    const wasActive = faqItem.classList.contains('active');
    
    // Close all other FAQs
    document.querySelectorAll('.faq-item').forEach(item => {
        item.classList.remove('active');
    });

    // Toggle current FAQ
    if (!wasActive) {
        faqItem.classList.add('active');
    }
}

function handleCategoryClick(event) {
    event.preventDefault();
    const category = event.currentTarget.dataset.category;

    // Update active category
    document.querySelectorAll('.help-categories a').forEach(link => {
        link.classList.remove('active');
    });
    event.currentTarget.classList.add('active');

    // Filter FAQs
    document.querySelectorAll('.faq-item').forEach(item => {
        if (category === 'all' || item.dataset.category === category) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

async function handleContactSubmission(event) {
    event.preventDefault();
    try {
        const formData = new FormData(event.target);
        const contactData = {
            name: formData.get('name'),
            email: formData.get('email'),
            subject: formData.get('subject'),
            message: formData.get('message')
        };

        await apiRequest('/contact', {
            method: 'POST',
            body: JSON.stringify(contactData)
        });

        showAlert('Message sent successfully', 'success');
        event.target.reset();
    } catch (error) {
        showAlert('Failed to send message', 'error');
        console.error('Contact form error:', error);
    }
}

function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    
    document.querySelectorAll('.faq-item').forEach(item => {
        const question = item.querySelector('.faq-question h3').textContent.toLowerCase();
        const answer = item.querySelector('.faq-answer p').textContent.toLowerCase();
        
        if (question.includes(searchTerm) || answer.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

// Chat functionality
function initializeChat() {
    const chatModal = document.getElementById('chatModal');
    const chatToggle = document.getElementById('chatToggle');
    
    if (chatToggle && chatModal) {
        chatToggle.addEventListener('click', () => {
            chatModal.style.display = chatModal.style.display === 'none' ? 'flex' : 'none';
        });

        document.querySelector('.close-chat')?.addEventListener('click', () => {
            chatModal.style.display = 'none';
        });
    }
}

async function handleChatSubmission(event) {
    event.preventDefault();
    const messageInput = document.getElementById('chatMessage');
    const message = messageInput.value.trim();
    
    if (!message) return;

    try {
        // Add message to chat
        appendChatMessage(message, 'user');
        messageInput.value = '';

        // Send message to API
        const response = await apiRequest('/chat', {
            method: 'POST',
            body: JSON.stringify({ message })
        });

        // Add response to chat
        appendChatMessage(response.message, 'agent');
    } catch (error) {
        showAlert('Failed to send message', 'error');
        console.error('Chat error:', error);
    }
}

function appendChatMessage(message, type) {
    const chatMessages = document.querySelector('.chat-messages');
    const messageElement = document.createElement('div');
    messageElement.className = `chat-message ${type}-message`;
    messageElement.textContent = message;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
} 