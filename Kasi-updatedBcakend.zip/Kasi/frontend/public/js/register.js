document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    const passwordInputs = document.querySelectorAll('.password-input input');
    const toggleButtons = document.querySelectorAll('.toggle-password');

    // Toggle password visibility
    toggleButtons.forEach((button, index) => {
        button.addEventListener('click', () => {
            const input = passwordInputs[index];
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            button.classList.toggle('fa-eye');
            button.classList.toggle('fa-eye-slash');
        });
    });

    // Handle form submission
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            showAlert('Passwords do not match', 'error');
            return;
        }

        const formData = {
            firstName: document.getElementById('firstName').value,
            lastName: document.getElementById('lastName').value,
            email: document.getElementById('email').value,
            phoneNumber: document.getElementById('phoneNumber').value,
            password: password,
            nextOfKin: document.getElementById('nextOfKin').value || null
        };

        try {
            const response = await apiRequest('/auth/register', {
                method: 'POST',
                body: JSON.stringify(formData)
            });

            if (response) {
                showAlert('Registration successful! Please login.', 'success');
                setTimeout(() => {
                    window.location.href = '/login.html';
                }, 2000);
            }
        } catch (error) {
            showAlert(error.message || 'Registration failed. Please try again.', 'error');
        }
    });
}); 