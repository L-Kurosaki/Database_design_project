// Function to update navigation based on authentication status
function updateNavigation() {
    const isLoggedIn = isAuthenticated();
    const guestNav = document.getElementById('guestNav');
    const guestAuth = document.getElementById('guestAuth');
    const userNav = document.getElementById('userNav');
    const userMenu = document.getElementById('userMenu');

    if (isLoggedIn) {
        // Hide guest elements
        if (guestNav) guestNav.style.display = 'none';
        if (guestAuth) guestAuth.style.display = 'none';
        // Show user elements
        if (userNav) userNav.style.display = 'flex';
        if (userMenu) userMenu.style.display = 'flex';
        // Update user greeting
        const user = getCurrentUser();
        if (user && userMenu) {
            const greeting = userMenu.querySelector('#userGreeting');
            if (greeting) {
                greeting.textContent = `Welcome, ${user.name}`;
            }
        }
    } else {
        // Show guest elements
        if (guestNav) guestNav.style.display = 'flex';
        if (guestAuth) guestAuth.style.display = 'flex';
        // Hide user elements
        if (userNav) userNav.style.display = 'none';
        if (userMenu) userMenu.style.display = 'none';
    }
}

// Initialize navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateNavigation();
});

// Update navigation when auth state changes
window.addEventListener('auth-state-changed', updateNavigation); 