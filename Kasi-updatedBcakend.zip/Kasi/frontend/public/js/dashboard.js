document.addEventListener('DOMContentLoaded', () => {
    loadDashboardData();
    setupEventListeners();
});

async function loadDashboardData() {
    try {
        const user = getCurrentUser();
        if (!user) {
            window.location.href = 'login.html';
            return;
        }

        // Load user's recent bookings
        const bookingsResponse = await apiRequest('/bookings/recent');
        displayRecentBookings(bookingsResponse.bookings);

        // Load user's recent complaints
        const complaintsResponse = await apiRequest('/complaints/recent');
        displayRecentComplaints(complaintsResponse.complaints);

        // Update user profile section
        updateProfileSection(user);
    } catch (error) {
        showAlert('Failed to load dashboard data', 'error');
        console.error('Dashboard error:', error);
    }
}

function setupEventListeners() {
    // Quick booking form
    document.getElementById('quickBookForm')?.addEventListener('submit', handleQuickBook);

    // Profile update form
    document.getElementById('profileUpdateForm')?.addEventListener('submit', handleProfileUpdate);

    // Notification preferences
    document.querySelectorAll('.notification-toggle')?.forEach(toggle => {
        toggle.addEventListener('change', handleNotificationToggle);
    });
}

function displayRecentBookings(bookings) {
    const container = document.getElementById('recentBookings');
    if (!container || !bookings?.length) {
        container.innerHTML = '<p>No recent bookings found.</p>';
        return;
    }

    container.innerHTML = bookings.map(booking => `
        <div class="booking-card">
            <div class="booking-header">
                <h4>${booking.route.from} to ${booking.route.to}</h4>
                <span class="booking-status status-${booking.status.toLowerCase()}">${booking.status}</span>
            </div>
            <div class="booking-details">
                <p><i class="fas fa-calendar"></i> ${new Date(booking.date).toLocaleDateString()}</p>
                <p><i class="fas fa-clock"></i> ${booking.time}</p>
                <p><i class="fas fa-ticket-alt"></i> Seat ${booking.seatNumber}</p>
            </div>
            <div class="booking-actions">
                <button onclick="viewBookingDetails('${booking.id}')" class="btn btn-primary">View Details</button>
                ${booking.status === 'UPCOMING' ? `<button onclick="cancelBooking('${booking.id}')" class="btn">Cancel</button>` : ''}
            </div>
        </div>
    `).join('');
}

function displayRecentComplaints(complaints) {
    const container = document.getElementById('recentComplaints');
    if (!container || !complaints?.length) {
        container.innerHTML = '<p>No recent complaints found.</p>';
        return;
    }

    container.innerHTML = complaints.map(complaint => `
        <div class="complaint-card">
            <div class="complaint-header">
                <h4>${complaint.subject}</h4>
                <span class="status-${complaint.status.toLowerCase()}">${complaint.status}</span>
            </div>
            <p class="complaint-date">Submitted on ${new Date(complaint.createdAt).toLocaleDateString()}</p>
            <p class="complaint-preview">${complaint.message.substring(0, 100)}...</p>
            <button onclick="viewComplaintDetails('${complaint.id}')" class="btn">View Details</button>
        </div>
    `).join('');
}

function updateProfileSection(user) {
    const profileSection = document.getElementById('userProfile');
    if (!profileSection) return;

    document.getElementById('userName').textContent = `${user.firstName} ${user.lastName}`;
    document.getElementById('userEmail').textContent = user.email;
    document.getElementById('userPhone').textContent = user.phone || 'Not provided';
}

async function handleQuickBook(event) {
    event.preventDefault();
    try {
        const formData = new FormData(event.target);
        const bookingData = {
            from: formData.get('from'),
            to: formData.get('to'),
            date: formData.get('date')
        };

        // Redirect to schedule page with pre-filled search
        const params = new URLSearchParams(bookingData);
        window.location.href = `schedule.html?${params.toString()}`;
    } catch (error) {
        showAlert('Failed to process quick booking', 'error');
        console.error('Quick booking error:', error);
    }
}

async function handleProfileUpdate(event) {
    event.preventDefault();
    try {
        const formData = new FormData(event.target);
        const profileData = {
            firstName: formData.get('firstName'),
            lastName: formData.get('lastName'),
            phone: formData.get('phone'),
            email: formData.get('email')
        };

        const response = await apiRequest('/users/profile', {
            method: 'PUT',
            body: JSON.stringify(profileData)
        });

        // Update local storage with new user data
        localStorage.setItem('user', JSON.stringify(response.user));
        
        showAlert('Profile updated successfully', 'success');
        updateProfileSection(response.user);
    } catch (error) {
        showAlert('Failed to update profile', 'error');
        console.error('Profile update error:', error);
    }
}

async function handleNotificationToggle(event) {
    try {
        const type = event.target.dataset.type;
        const enabled = event.target.checked;

        await apiRequest('/users/notifications', {
            method: 'PUT',
            body: JSON.stringify({ type, enabled })
        });

        showAlert('Notification preferences updated', 'success');
    } catch (error) {
        showAlert('Failed to update notification preferences', 'error');
        console.error('Notification toggle error:', error);
        // Revert toggle if update failed
        event.target.checked = !event.target.checked;
    }
}

function viewBookingDetails(bookingId) {
    window.location.href = `booking-history.html?bookingId=${bookingId}`;
}

function viewComplaintDetails(complaintId) {
    window.location.href = `complaints.html?complaintId=${complaintId}`;
}

async function cancelBooking(bookingId) {
    if (!confirm('Are you sure you want to cancel this booking?')) return;

    try {
        await apiRequest(`/bookings/${bookingId}/cancel`, { method: 'POST' });
        showAlert('Booking cancelled successfully', 'success');
        loadDashboardData(); // Refresh dashboard data
    } catch (error) {
        showAlert('Failed to cancel booking', 'error');
        console.error('Booking cancellation error:', error);
    }
} 