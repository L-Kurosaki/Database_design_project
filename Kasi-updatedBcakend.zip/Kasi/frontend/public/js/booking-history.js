document.addEventListener('DOMContentLoaded', () => {
    loadBookings();
    setupEventListeners();
});

let currentBookings = [];

function setupEventListeners() {
    // Search functionality
    document.getElementById('searchBooking').addEventListener('input', filterBookings);
    
    // Status filter
    document.getElementById('statusFilter').addEventListener('change', filterBookings);
    
    // Date filter
    document.getElementById('dateFilter').addEventListener('change', filterBookings);

    // Cancellation reason change
    document.getElementById('cancellationReason').addEventListener('change', (e) => {
        const otherReasonGroup = document.getElementById('otherReasonGroup');
        otherReasonGroup.style.display = e.target.value === 'other' ? 'block' : 'none';
    });
}

async function loadBookings() {
    try {
        const response = await apiRequest('/bookings');
        if (response) {
            currentBookings = response.bookings;
            displayBookings(currentBookings);
        }
    } catch (error) {
        showAlert('Failed to load bookings', 'error');
    }
}

function displayBookings(bookings) {
    const bookingsContainer = document.getElementById('bookingsList');
    bookingsContainer.innerHTML = '';

    if (bookings.length === 0) {
        bookingsContainer.innerHTML = `
            <div class="no-results">
                <i class="fas fa-ticket"></i>
                <p>No bookings found</p>
            </div>
        `;
        return;
    }

    bookings.forEach(booking => {
        const card = document.createElement('div');
        card.className = `booking-card ${booking.status.toLowerCase()}`;
        card.innerHTML = `
            <div class="booking-header">
                <span class="booking-ref">#${booking.reference}</span>
                <span class="booking-status ${booking.status.toLowerCase()}">${booking.status}</span>
            </div>
            <div class="booking-content">
                <div class="journey-details">
                    <div class="route">
                        <span class="city">${booking.origin}</span>
                        <i class="fas fa-arrow-right"></i>
                        <span class="city">${booking.destination}</span>
                    </div>
                    <div class="schedule">
                        <i class="fas fa-calendar"></i>
                        <span>${new Date(booking.travelDate).toLocaleDateString()}</span>
                        <i class="fas fa-clock"></i>
                        <span>${booking.departureTime}</span>
                    </div>
                </div>
                <div class="passenger-details">
                    <i class="fas fa-users"></i>
                    <span>${booking.passengers} passenger(s)</span>
                </div>
                <div class="price-details">
                    <span class="price">R${booking.totalAmount}</span>
                </div>
            </div>
            <div class="booking-actions">
                <button onclick="viewBookingDetails('${booking.reference}')" class="btn">
                    <i class="fas fa-eye"></i> View Details
                </button>
                ${booking.status === 'UPCOMING' ? `
                    <button onclick="downloadTicket('${booking.reference}')" class="btn">
                        <i class="fas fa-download"></i> Download Ticket
                    </button>
                    <button onclick="showCancelModal('${booking.reference}')" class="btn btn-danger">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                ` : ''}
            </div>
        `;
        bookingsContainer.appendChild(card);
    });
}

async function viewBookingDetails(reference) {
    try {
        const response = await apiRequest(`/bookings/${reference}`);
        if (response) {
            const booking = response.booking;
            
            // Update booking details in modal
            document.getElementById('bookingRef').textContent = booking.reference;
            document.getElementById('bookingStatus').textContent = booking.status;
            document.getElementById('travelDate').textContent = new Date(booking.travelDate).toLocaleDateString();
            document.getElementById('routeDetails').textContent = `${booking.origin} to ${booking.destination}`;
            
            // Update passenger details
            const passengerDetails = document.getElementById('passengerDetails');
            passengerDetails.innerHTML = booking.passengers.map(passenger => `
                <div class="passenger">
                    <p><strong>Name:</strong> ${passenger.name}</p>
                    <p><strong>ID/Passport:</strong> ${passenger.idNumber}</p>
                    <p><strong>Seat:</strong> ${passenger.seatNumber}</p>
                </div>
            `).join('');
            
            // Update payment details
            document.getElementById('amountPaid').textContent = booking.totalAmount;
            document.getElementById('paymentMethod').textContent = booking.paymentMethod;
            document.getElementById('paymentDate').textContent = new Date(booking.paymentDate).toLocaleDateString();
            
            // Show/hide action buttons based on status
            document.getElementById('cancelBtn').style.display = 
                booking.status === 'UPCOMING' ? 'block' : 'none';
            
            // Show modal
            document.getElementById('bookingDetailsModal').style.display = 'block';
        }
    } catch (error) {
        showAlert('Failed to load booking details', 'error');
    }
}

async function downloadTicket(reference) {
    try {
        const response = await apiRequest(`/bookings/${reference}/ticket`, {
            method: 'GET',
            responseType: 'blob'
        });

        if (response) {
            // Create a blob from the PDF Stream
            const blob = new Blob([response], { type: 'application/pdf' });
            // Create an object URL for the blob
            const url = window.URL.createObjectURL(blob);
            // Create a new link
            const link = document.createElement('a');
            link.href = url;
            link.download = `ticket-${reference}.pdf`;
            // Append to html link element page
            document.body.appendChild(link);
            // Start download
            link.click();
            // Clean up and remove the link
            link.parentNode.removeChild(link);
            showAlert('Ticket downloaded successfully', 'success');
        }
    } catch (error) {
        showAlert('Failed to download ticket', 'error');
    }
}

function showCancelModal(reference) {
    // Store the booking reference for use in confirmation
    document.getElementById('cancellationModal').dataset.bookingRef = reference;
    document.getElementById('cancellationModal').style.display = 'block';
}

async function confirmCancellation() {
    const modal = document.getElementById('cancellationModal');
    const reference = modal.dataset.bookingRef;
    const reason = document.getElementById('cancellationReason').value;
    const otherReason = document.getElementById('otherReason').value;

    const cancellationData = {
        reason: reason === 'other' ? otherReason : reason
    };

    try {
        const response = await apiRequest(`/bookings/${reference}/cancel`, {
            method: 'POST',
            body: JSON.stringify(cancellationData)
        });

        if (response) {
            showAlert('Booking cancelled successfully', 'success');
            modal.style.display = 'none';
            // Reset form
            document.getElementById('cancellationReason').value = '';
            document.getElementById('otherReason').value = '';
            document.getElementById('otherReasonGroup').style.display = 'none';
            // Reload bookings
            await loadBookings();
        }
    } catch (error) {
        showAlert('Failed to cancel booking', 'error');
    }
}

function filterBookings() {
    const searchTerm = document.getElementById('searchBooking').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const dateFilter = document.getElementById('dateFilter').value;

    let filteredBookings = currentBookings;

    // Apply search filter
    if (searchTerm) {
        filteredBookings = filteredBookings.filter(booking => 
            booking.reference.toLowerCase().includes(searchTerm)
        );
    }

    // Apply status filter
    if (statusFilter) {
        filteredBookings = filteredBookings.filter(booking => 
            booking.status.toLowerCase() === statusFilter.toLowerCase()
        );
    }

    // Apply date filter
    if (dateFilter) {
        const today = new Date();
        const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        const startOfYear = new Date(today.getFullYear(), 0, 1);

        filteredBookings = filteredBookings.filter(booking => {
            const bookingDate = new Date(booking.travelDate);
            switch (dateFilter) {
                case 'today':
                    return bookingDate.toDateString() === new Date().toDateString();
                case 'week':
                    return bookingDate >= startOfWeek;
                case 'month':
                    return bookingDate >= startOfMonth;
                case 'year':
                    return bookingDate >= startOfYear;
                default:
                    return true;
            }
        });
    }

    displayBookings(filteredBookings);
}

function switchTab(tab) {
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    let filteredBookings;
    switch (tab) {
        case 'upcoming':
            filteredBookings = currentBookings.filter(b => b.status === 'UPCOMING');
            break;
        case 'completed':
            filteredBookings = currentBookings.filter(b => b.status === 'COMPLETED');
            break;
        case 'cancelled':
            filteredBookings = currentBookings.filter(b => b.status === 'CANCELLED');
            break;
    }
    displayBookings(filteredBookings);
}

function closeModal() {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        modal.style.display = 'none';
    }
}

// Close modals when clicking outside
window.onclick = (event) => {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }
};

// Close modals when clicking close button
document.querySelectorAll('.close').forEach(closeBtn => {
    closeBtn.onclick = () => {
        closeBtn.closest('.modal').style.display = 'none';
    };
}); 