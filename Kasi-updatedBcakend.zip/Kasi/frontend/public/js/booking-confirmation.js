// Get booking details from URL parameters
function getBookingDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    return {
        reference: urlParams.get('reference') || 'KBT' + Math.random().toString(36).substr(2, 9).toUpperCase(),
        origin: urlParams.get('origin') || '',
        destination: urlParams.get('destination') || '',
        date: urlParams.get('date') || '',
        time: urlParams.get('time') || '',
        seat: urlParams.get('seat') || '',
        passenger: urlParams.get('passenger') || ''
    };
}

// Populate ticket details
function populateTicketDetails() {
    const details = getBookingDetails();
    document.getElementById('bookingReference').textContent = details.reference;
    document.getElementById('origin').textContent = details.origin;
    document.getElementById('destination').textContent = details.destination;
    document.getElementById('travelDate').textContent = details.date;
    document.getElementById('departureTime').textContent = details.time;
    document.getElementById('seatNumber').textContent = details.seat;
    document.getElementById('passengerName').textContent = details.passenger;

    // Generate QR code
    generateQRCode(details);
}

// Generate QR code
function generateQRCode(details) {
    const qrData = JSON.stringify(details);
    new QRCode(document.getElementById("qrCode"), {
        text: qrData,
        width: 128,
        height: 128,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });
}

// Download ticket as PDF
function downloadTicket() {
    // Implementation will be added when we integrate a PDF generation library
    alert('Download functionality will be implemented soon');
}

// Email ticket to user
function emailTicket() {
    // Implementation will be added when we integrate email service
    alert('Email functionality will be implemented soon');
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    if (!isAuthenticated()) {
        window.location.href = 'login.html';
        return;
    }

    // Set user greeting
    const user = getCurrentUser();
    if (user) {
        document.getElementById('userGreeting').textContent = `Welcome, ${user.name}`;
    }

    // Populate ticket details
    populateTicketDetails();
});

// Logout function
function logout() {
    doLogout();
    window.location.href = 'login.html';
} 