document.addEventListener('DOMContentLoaded', () => {
    loadBookingData();
    setupEventListeners();
});

let currentBooking = {
    route: null,
    seats: [],
    passengers: [],
    totalAmount: 0
};

function setupEventListeners() {
    // Step navigation
    document.querySelectorAll('.step-btn').forEach(btn => {
        btn.addEventListener('click', handleStepNavigation);
    });

    // Seat selection
    document.getElementById('seatMap')?.addEventListener('click', handleSeatSelection);

    // Passenger form
    document.getElementById('passengerForm')?.addEventListener('submit', handlePassengerSubmission);

    // Terms acceptance
    document.getElementById('termsCheckbox')?.addEventListener('change', validateTerms);

    // Final submission
    document.getElementById('confirmBookingBtn')?.addEventListener('click', handleBookingConfirmation);
}

async function loadBookingData() {
    try {
        // Get route ID from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const routeId = urlParams.get('routeId');
        
        if (!routeId) {
            throw new Error('No route selected');
        }

        // Load route details
        const routeResponse = await apiRequest(`/routes/${routeId}`);
        currentBooking.route = routeResponse;

        // Load seat availability
        const seatsResponse = await apiRequest(`/routes/${routeId}/seats`);
        updateSeatMap(seatsResponse.seats);

        // Update booking summary
        updateBookingSummary();
    } catch (error) {
        showAlert('Failed to load booking details', 'error');
        console.error('Booking data error:', error);
    }
}

function updateSeatMap(seats) {
    const seatMap = document.getElementById('seatMap');
    if (!seatMap) return;

    seatMap.innerHTML = seats.map(seat => `
        <div class="seat ${seat.status.toLowerCase()}" 
             data-seat-number="${seat.number}"
             data-price="${seat.price}"
             ${seat.status === 'OCCUPIED' ? 'disabled' : ''}>
            ${seat.number}
        </div>
    `).join('');
}

function handleSeatSelection(event) {
    const seat = event.target.closest('.seat');
    if (!seat || seat.classList.contains('occupied')) return;

    const seatNumber = seat.dataset.seatNumber;
    const price = parseFloat(seat.dataset.price);

    if (seat.classList.contains('selected')) {
        // Deselect seat
        seat.classList.remove('selected');
        currentBooking.seats = currentBooking.seats.filter(s => s.number !== seatNumber);
        currentBooking.totalAmount -= price;
    } else {
        // Select seat
        seat.classList.add('selected');
        currentBooking.seats.push({
            number: seatNumber,
            price: price
        });
        currentBooking.totalAmount += price;
    }

    updateBookingSummary();
    validateStep('seats');
}

function handlePassengerSubmission(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    const passenger = {
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
        idNumber: formData.get('idNumber'),
        phone: formData.get('phone'),
        email: formData.get('email')
    };

    currentBooking.passengers.push(passenger);
    updatePassengerList();
    event.target.reset();

    validateStep('passengers');
}

function updatePassengerList() {
    const container = document.getElementById('passengerList');
    if (!container) return;

    container.innerHTML = currentBooking.passengers.map((passenger, index) => `
        <div class="passenger-card">
            <div class="passenger-info">
                <h4>${passenger.firstName} ${passenger.lastName}</h4>
                <p>ID: ${passenger.idNumber}</p>
                <p>Contact: ${passenger.phone}</p>
            </div>
            <button onclick="removePassenger(${index})" class="btn">Remove</button>
        </div>
    `).join('');
}

function removePassenger(index) {
    currentBooking.passengers.splice(index, 1);
    updatePassengerList();
    validateStep('passengers');
}

function updateBookingSummary() {
    const summary = document.getElementById('bookingSummary');
    if (!summary || !currentBooking.route) return;

    summary.innerHTML = `
        <div class="summary-section">
            <h3>Route Details</h3>
            <p>From: ${currentBooking.route.from}</p>
            <p>To: ${currentBooking.route.to}</p>
            <p>Date: ${new Date(currentBooking.route.date).toLocaleDateString()}</p>
            <p>Time: ${currentBooking.route.time}</p>
        </div>
        <div class="summary-section">
            <h3>Selected Seats</h3>
            ${currentBooking.seats.map(seat => `
                <p>Seat ${seat.number}: R${seat.price.toFixed(2)}</p>
            `).join('')}
        </div>
        <div class="summary-section">
            <h3>Total Amount</h3>
            <p class="total-amount">R${currentBooking.totalAmount.toFixed(2)}</p>
        </div>
    `;
}

function validateStep(step) {
    const nextBtn = document.querySelector(`[data-next-step="${step}"]`);
    if (!nextBtn) return;

    switch (step) {
        case 'seats':
            nextBtn.disabled = currentBooking.seats.length === 0;
            break;
        case 'passengers':
            nextBtn.disabled = currentBooking.passengers.length !== currentBooking.seats.length;
            break;
        case 'terms':
            nextBtn.disabled = !document.getElementById('termsCheckbox')?.checked;
            break;
    }
}

function validateTerms(event) {
    validateStep('terms');
}

function handleStepNavigation(event) {
    const currentStep = event.target.closest('.booking-step');
    const nextStepId = event.target.dataset.nextStep;
    
    if (!nextStepId || !validateStep(currentStep.id)) return;

    // Hide current step
    currentStep.classList.remove('active');
    
    // Show next step
    document.getElementById(nextStepId).classList.add('active');
    
    // Update progress indicator
    updateProgressIndicator(nextStepId);
}

function updateProgressIndicator(currentStepId) {
    const steps = ['seats', 'passengers', 'payment', 'confirmation'];
    const currentIndex = steps.indexOf(currentStepId);
    
    steps.forEach((step, index) => {
        const indicator = document.querySelector(`[data-step="${step}"]`);
        if (index <= currentIndex) {
            indicator.classList.add('active');
        } else {
            indicator.classList.remove('active');
        }
    });
}

async function handleBookingConfirmation() {
    try {
        if (!validateBookingData()) {
            throw new Error('Please complete all required information');
        }

        const bookingData = {
            routeId: currentBooking.route.id,
            seats: currentBooking.seats.map(seat => seat.number),
            passengers: currentBooking.passengers,
            totalAmount: currentBooking.totalAmount
        };

        const response = await apiRequest('/bookings', {
            method: 'POST',
            body: JSON.stringify(bookingData)
        });

        // Redirect to payment page
        window.location.href = `payment.html?bookingId=${response.bookingId}`;
    } catch (error) {
        showAlert(error.message || 'Failed to confirm booking', 'error');
        console.error('Booking confirmation error:', error);
    }
}

function validateBookingData() {
    return (
        currentBooking.route &&
        currentBooking.seats.length > 0 &&
        currentBooking.passengers.length === currentBooking.seats.length &&
        document.getElementById('termsCheckbox')?.checked
    );
} 