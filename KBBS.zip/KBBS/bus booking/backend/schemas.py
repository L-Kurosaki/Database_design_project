from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import date, time
from enum import Enum

class UserTypeEnum(str, Enum):
    Passenger = 'Passenger'
    Driver = 'Driver'
    Admin = 'Admin'

class BusStateEnum(str, Enum):
    Active = 'Active'
    UnderMaintenance = 'Under Maintenance'

class BookingStatusEnum(str, Enum):
    Pending = 'Pending'
    Confirmed = 'Confirmed'
    Cancelled = 'Cancelled'

class ComplaintTypeEnum(str, Enum):
    PaymentIssue = 'Payment issue'
    AppBug = 'App bug'
    SeatIssue = 'Seat issue'
    Other = 'Other'

class ComplaintStatusEnum(str, Enum):
    Pending = 'Pending'
    InProgress = 'In Progress'
    Resolved = 'Resolved'

class UserAccountBase(BaseModel):
    Reg_Date: date
    Names: str
    Age: int
    Email: EmailStr
    Phone_num: Optional[str]
    Ratings: Optional[float]
    UserType: UserTypeEnum

class UserAccountCreate(UserAccountBase):
    Password: str

class UserAccountResponse(UserAccountBase):
    User_ID: int

    class Config:
        orm_mode = True

class PermitBase(BaseModel):
    License: str
    Names: Optional[str]
    Permit_Status: str
    UserID: int

class PermitCreate(PermitBase):
    pass

class PermitResponse(PermitBase):
    PermitID: int

    class Config:
        orm_mode = True

class BusBase(BaseModel):
    Model_Brand: Optional[str]
    Capacity: int
    Bus_state: Optional[BusStateEnum]

class BusCreate(BusBase):
    UserID: int

class BusResponse(BusBase):
    Bus_ID: int
    UserID: int

    class Config:
        orm_mode = True

class RouteBase(BaseModel):
    Source: Optional[str]
    Destination: Optional[str]
    Stops: Optional[str]
    Distance_KM: Optional[float]
    Estimated_Time: Optional[time]

class RouteCreate(RouteBase):
    pass

class RouteResponse(RouteBase):
    RouteID: int

    class Config:
        orm_mode = True

class ScheduleBase(BaseModel):
    DepartureDate: date
    DepartureTime: time
    ArrivalTime: time
    SeatsAvailable: int

class ScheduleCreate(ScheduleBase):
    BusID: int
    RouteID: int

class ScheduleResponse(ScheduleBase):
    ScheduleID: int
    BusID: int
    RouteID: int

    class Config:
        orm_mode = True

class BookingBase(BaseModel):
    Booking_Date: date
    Trip: Optional[str]
    Price: Optional[float]
    Booking_Status: BookingStatusEnum
    Driver_Name: Optional[str]
    Payment: Optional[float]

class BookingCreate(BookingBase):
    Bus_ID: int
    UserID: int

class BookingResponse(BookingBase):
    Booking_ID: int
    Bus_ID: int
    UserID: int

    class Config:
        orm_mode = True

class PaymentBase(BaseModel):
    full_name: str
    email: EmailStr
    address: str
    city: str
    state: str
    zip_code: str
    name_on_card: str
    card_number: str
    exp_date: str
    cvv: str

class PaymentCreate(PaymentBase):
    pass

class PaymentResponse(PaymentBase):
    payment_id: int

    class Config:
        orm_mode = True

