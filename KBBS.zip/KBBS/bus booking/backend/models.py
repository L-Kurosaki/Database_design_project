from sqlalchemy import Column, Integer, String, Date, Enum, DECIMAL, ForeignKey, TIME, Text
from sqlalchemy.orm import relationship
from database import Base
import enum

class UserTypeEnum(enum.Enum):
    Passenger = 'Passenger'
    Driver = 'Driver'
    Admin = 'Admin'

class BusStateEnum(enum.Enum):
    Active = 'Active'
    UnderMaintenance = 'Under Maintenance'

class BookingStatusEnum(enum.Enum):
    Pending = 'Pending'
    Confirmed = 'Confirmed'
    Cancelled = 'Cancelled'

class ComplaintTypeEnum(enum.Enum):
    PaymentIssue = 'Payment issue'
    AppBug = 'App bug'
    SeatIssue = 'Seat issue'
    Other = 'Other'

class ComplaintStatusEnum(enum.Enum):
    Pending = 'Pending'
    InProgress = 'In Progress'
    Resolved = 'Resolved'

class UserAccount(Base):
    __tablename__ = 'UserAccount'

    User_ID = Column(Integer, primary_key=True, index=True)
    Reg_Date = Column(Date, nullable=False)
    Password = Column(String(255), nullable=False)
    PermitID = Column(Integer)
    Names = Column(String(100), nullable=False)
    Age = Column(Integer, nullable=False)
    Email = Column(String(100), unique=True, nullable=False, index=True)
    Phone_num = Column(String(15))
    Ratings = Column(DECIMAL(2,1))
    Bus_ID = Column(Integer)
    UserType = Column(Enum(UserTypeEnum), nullable=False)

    # relationships
    permits = relationship("Permit", back_populates="user")
    buses = relationship("Bus", back_populates="driver")
    bookings = relationship("Booking", back_populates="user")
    seats = relationship("Seat", back_populates="user")
    support_requests = relationship("SupportRequest", back_populates="user")
    next_of_kin = relationship("NextOfKin", back_populates="user", uselist=False)

class Permit(Base):
    __tablename__ = 'Permit'

    PermitID = Column(Integer, primary_key=True, index=True)
    License = Column(String(50), unique=True, nullable=False)
    Names = Column(String(100))
    UserID = Column(Integer, ForeignKey('UserAccount.User_ID'), nullable=False)
    Permit_Status = Column(String(50), nullable=False)

    user = relationship("UserAccount", back_populates="permits")

class Bus(Base):
    __tablename__ = 'Bus'

    Bus_ID = Column(Integer, primary_key=True, index=True)
    Model_Brand = Column(String(100))
    Capacity = Column(Integer, nullable=False)
    Bus_state = Column(Enum(BusStateEnum), default=BusStateEnum.Active)
    UserID = Column(Integer, ForeignKey('UserAccount.User_ID'), nullable=False)

    driver = relationship("UserAccount", back_populates="buses")
    schedules = relationship("Schedule", back_populates="bus")
    bookings = relationship("Booking", back_populates="bus")

class NextOfKin(Base):
    __tablename__ = 'NextOfKin'

    User_ID = Column(Integer, ForeignKey('UserAccount.User_ID'), primary_key=True)
    Names = Column(String(100), nullable=False)
    Phone_num = Column(String(15), nullable=False)

    user = relationship("UserAccount", back_populates="next_of_kin")

class Route(Base):
    __tablename__ = 'Route'

    RouteID = Column(Integer, primary_key=True, index=True)
    Source = Column(String(100))
    Destination = Column(String(100))
    Stops = Column(Text)
    Distance_KM = Column(DECIMAL(5,2))
    Estimated_Time = Column(TIME)

    schedules = relationship("Schedule", back_populates="route")

class Schedule(Base):
    __tablename__ = 'Schedule'

    ScheduleID = Column(Integer, primary_key=True, index=True)
    BusID = Column(Integer, ForeignKey('Bus.Bus_ID'), nullable=False)
    RouteID = Column(Integer, ForeignKey('Route.RouteID'), nullable=False)
    DepartureDate = Column(Date, nullable=False)
    DepartureTime = Column(TIME, nullable=False)
    ArrivalTime = Column(TIME, nullable=False)
    SeatsAvailable = Column(Integer, nullable=False)

    bus = relationship("Bus", back_populates="schedules")
    route = relationship("Route", back_populates="schedules")
    seats = relationship("Seat", back_populates="schedule")

class Booking(Base):
    __tablename__ = 'Booking'

    Booking_ID = Column(Integer, primary_key=True, index=True)
    Booking_Date = Column(Date, nullable=False)
    Bus_ID = Column(Integer, ForeignKey('Bus.Bus_ID'), nullable=False)
    Trip = Column(String(100))
    Price = Column(DECIMAL(8,2))
    Booking_Status = Column(Enum(BookingStatusEnum), nullable=False)
    Driver_Name = Column(String(100))
    Payment = Column(DECIMAL(8,2))
    UserID = Column(Integer, ForeignKey('UserAccount.User_ID'), nullable=False)

    user = relationship("UserAccount", back_populates="bookings")
    bus = relationship("Bus", back_populates="bookings")

class Seat(Base):
    __tablename__ = 'Seat'

    Seat_ID = Column(Integer, primary_key=True, index=True)
    User_ID = Column(Integer, ForeignKey('UserAccount.User_ID'))
    ScheduleID = Column(Integer, ForeignKey('Schedule.ScheduleID'))
    Availability = Column(Enum('Available', 'Booked'), nullable=False, default='Available')

    user = relationship("UserAccount", back_populates="seats")
    schedule = relationship("Schedule", back_populates="seats")

class SupportRequest(Base):
    __tablename__ = 'SupportRequest'

    Complaint_ID = Column(Integer, primary_key=True, index=True)
    UserID = Column(Integer, ForeignKey('UserAccount.User_ID'), nullable=False)
    Complaint_Type = Column(Enum(ComplaintTypeEnum), nullable=False)
    Description = Column(Text)
    Status = Column(Enum(ComplaintStatusEnum), default=ComplaintStatusEnum.Pending)
    DateSubmitted = Column(Date, nullable=False)
    DateResolved = Column(Date)

    user = relationship("UserAccount", back_populates="support_requests")
