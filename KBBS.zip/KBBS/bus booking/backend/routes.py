from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import models, schemas
from database import SessionLocal, engine

models.Base.metadata.create_all(bind=engine)

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/users/", response_model=schemas.UserAccountResponse)
def create_user(user: schemas.UserAccountCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.UserAccount).filter(models.UserAccount.Email == user.Email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = models.UserAccount(
        Reg_Date=user.Reg_Date,
        Password=user.Password,
        Names=user.Names,
        Age=user.Age,
        Email=user.Email,
        Phone_num=user.Phone_num,
        Ratings=user.Ratings,
        UserType=user.UserType,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.get("/users/{user_id}", response_model=schemas.UserAccountResponse)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.UserAccount).filter(models.UserAccount.User_ID == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.post("/bookings/", response_model=schemas.BookingResponse)
def create_booking(booking: schemas.BookingCreate, db: Session = Depends(get_db)):
    new_booking = models.Booking(
        Booking_Date=booking.Booking_Date,
        Trip=booking.Trip,
        Price=booking.Price,
        Booking_Status=booking.Booking_Status,
        Driver_Name=booking.Driver_Name,
        Payment=booking.Payment,
        Bus_ID=booking.Bus_ID,
        UserID=booking.UserID
    )
    db.add(new_booking)
    db.commit()
    db.refresh(new_booking)
    return new_booking
