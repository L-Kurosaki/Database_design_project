/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bus_management;

/**
 *
 * @author Sandile
 */
public class Bus_Management {

    public static void main(String[] args) {
        MainScreen mr=new MainScreen();
        mr.setLocationRelativeTo(null);
        mr.setVisible(true);
    }
}
