document.addEventListener('DOMContentLoaded', () => {
    loadComplaints();
    setupEventListeners();
});

let currentComplaints = [];

function setupEventListeners() {
    // New complaint form submission
    document.getElementById('complaintForm').addEventListener('submit', submitComplaint);

    // Search functionality
    document.getElementById('searchComplaint').addEventListener('input', filterComplaints);
}

async function loadComplaints() {
    try {
        const response = await apiRequest('/complaints');
        if (response) {
            currentComplaints = response.complaints;
            displayComplaints(currentComplaints);
        }
    } catch (error) {
        showAlert('Failed to load complaints', 'error');
    }
}

function displayComplaints(complaints) {
    const complaintsContainer = document.getElementById('complaintsList');
    complaintsContainer.innerHTML = '';

    if (complaints.length === 0) {
        complaintsContainer.innerHTML = `
            <div class="no-results">
                <i class="fas fa-clipboard-list"></i>
                <p>No complaints found</p>
            </div>
        `;
        return;
    }

    complaints.forEach(complaint => {
        const card = document.createElement('div');
        card.className = `complaint-card ${complaint.status.toLowerCase()}`;
        card.innerHTML = `
            <div class="complaint-header">
                <span class="complaint-id">#${complaint.id}</span>
                <span class="complaint-status ${complaint.status.toLowerCase()}">${complaint.status}</span>
            </div>
            <div class="complaint-content">
                <p class="complaint-type">${complaint.type}</p>
                <p class="complaint-description">${complaint.description}</p>
                <p class="complaint-date">Submitted: ${new Date(complaint.createdAt).toLocaleDateString()}</p>
            </div>
            <div class="complaint-actions">
                <button onclick="viewComplaintDetails('${complaint.id}')" class="btn">
                    <i class="fas fa-eye"></i> View Details
                </button>
            </div>
        `;
        complaintsContainer.appendChild(card);
    });
}

async function submitComplaint(e) {
    e.preventDefault();

    const formData = {
        bookingReference: document.getElementById('bookingReference').value,
        type: document.getElementById('complaintType').value,
        description: document.getElementById('complaintDescription').value
    };

    try {
        const response = await apiRequest('/complaints', {
            method: 'POST',
            body: JSON.stringify(formData)
        });

        if (response) {
            showAlert('Complaint submitted successfully', 'success');
            document.getElementById('complaintForm').reset();
            document.getElementById('newComplaintModal').style.display = 'none';
            await loadComplaints();
        }
    } catch (error) {
        showAlert('Failed to submit complaint', 'error');
    }
}

async function viewComplaintDetails(complaintId) {
    try {
        const response = await apiRequest(`/complaints/${complaintId}`);
        if (response) {
            const complaint = response.complaint;
            
            document.getElementById('complaintInfo').innerHTML = `
                <div class="detail-section">
                    <p><strong>Complaint ID:</strong> #${complaint.id}</p>
                    <p><strong>Type:</strong> ${complaint.type}</p>
                    <p><strong>Status:</strong> ${complaint.status}</p>
                    <p><strong>Submitted:</strong> ${new Date(complaint.createdAt).toLocaleDateString()}</p>
                    ${complaint.bookingReference ? `<p><strong>Booking Reference:</strong> ${complaint.bookingReference}</p>` : ''}
                    <p><strong>Description:</strong></p>
                    <p class="complaint-description">${complaint.description}</p>
                </div>
            `;

            displayUpdates(complaint.updates);
            document.getElementById('complaintDetailsModal').style.display = 'block';
        }
    } catch (error) {
        showAlert('Failed to load complaint details', 'error');
    }
}

function displayUpdates(updates) {
    const updatesContainer = document.getElementById('updatesList');
    updatesContainer.innerHTML = '';

    if (updates && updates.length > 0) {
        updates.forEach(update => {
            const updateElement = document.createElement('div');
            updateElement.className = 'update-item';
            updateElement.innerHTML = `
                <p class="update-date">${new Date(update.timestamp).toLocaleString()}</p>
                <p class="update-content">${update.content}</p>
                <p class="update-author">By: ${update.author}</p>
            `;
            updatesContainer.appendChild(updateElement);
        });
    } else {
        updatesContainer.innerHTML = '<p>No updates yet</p>';
    }
}

function switchTab(tab) {
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    let filteredComplaints;
    switch (tab) {
        case 'active':
            filteredComplaints = currentComplaints.filter(c => c.status === 'Open' || c.status === 'In Progress');
            break;
        case 'resolved':
            filteredComplaints = currentComplaints.filter(c => c.status === 'Resolved');
            break;
        case 'all':
            filteredComplaints = currentComplaints;
            break;
    }
    displayComplaints(filteredComplaints);
}

function showNewComplaintModal() {
    document.getElementById('newComplaintModal').style.display = 'block';
}

// Close modals when clicking outside
window.onclick = (event) => {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }
};

// Close modals when clicking close button
document.querySelectorAll('.close').forEach(closeBtn => {
    closeBtn.onclick = () => {
        closeBtn.closest('.modal').style.display = 'none';
    };
}); 