const express = require('express');
const router = express.Router();
const { 
    getSchedules, 
    getScheduleById,
    searchSchedules,
    getAvailableSeats
} = require('../controllers/schedule.controller');
const { verifyToken } = require('../middleware/auth');
const { validateScheduleSearch } = require('../middleware/validation');

// Public routes
router.get('/', getSchedules);
router.get('/search', validateScheduleSearch, searchSchedules);
router.get('/:id', getScheduleById);
router.get('/:id/seats', getAvailableSeats);

module.exports = router; 