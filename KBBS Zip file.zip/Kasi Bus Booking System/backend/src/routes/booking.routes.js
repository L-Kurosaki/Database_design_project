const express = require('express');
const router = express.Router();
const { 
    createBooking,
    getBookingById,
    cancelBooking,
    confirmPayment,
    getBookingHistory
} = require('../controllers/booking.controller');
const { verifyToken } = require('../middleware/auth');
const { validateBooking } = require('../middleware/validation');

// All booking routes are protected
router.post('/', [verifyToken, validateBooking], createBooking);
router.get('/:id', verifyToken, getBookingById);
router.post('/:id/cancel', verifyToken, cancelBooking);
router.post('/:id/payment', verifyToken, confirmPayment);
router.get('/user/:userId', verifyToken, getBookingHistory);

module.exports = router; 