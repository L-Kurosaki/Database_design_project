const express = require('express');
const router = express.Router();
const { 
    createComplaint,
    getComplaintById,
    getUserComplaints,
    updateComplaintStatus,
    addComplaintResponse
} = require('../controllers/complaint.controller');
const { verifyToken, isAdmin } = require('../middleware/auth');
const { validateComplaint } = require('../middleware/validation');

// User routes
router.post('/', [verifyToken, validateComplaint], createComplaint);
router.get('/user', verifyToken, getUserComplaints);
router.get('/:id', verifyToken, getComplaintById);

// Admin routes
router.put('/:id/status', [verifyToken, isAdmin], updateComplaintStatus);
router.post('/:id/response', [verifyToken, isAdmin], addComplaintResponse);

module.exports = router; 