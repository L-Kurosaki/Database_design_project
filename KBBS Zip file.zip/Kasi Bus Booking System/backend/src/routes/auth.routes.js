const express = require('express');
const router = express.Router();
const { register, login, logout, refreshToken } = require('../controllers/auth.controller');
const { validateRegister, validateLogin } = require('../middleware/validation');
const { verifyToken } = require('../middleware/auth');

// Authentication routes
router.post('/register', validateRegister, register);
router.post('/login', validateLogin, login);
router.post('/logout', verifyToken, logout);
router.post('/refresh-token', refreshToken);

module.exports = router; 