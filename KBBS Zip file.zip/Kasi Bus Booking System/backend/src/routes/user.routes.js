const express = require('express');
const router = express.Router();
const { 
    getProfile, 
    updateProfile, 
    updatePassword,
    getBookingHistory
} = require('../controllers/user.controller');
const { verifyToken } = require('../middleware/auth');
const { validateProfileUpdate, validatePasswordUpdate } = require('../middleware/validation');

// User routes - all protected by verifyToken middleware
router.get('/profile', verifyToken, getProfile);
router.put('/profile', [verifyToken, validateProfileUpdate], updateProfile);
router.put('/password', [verifyToken, validatePasswordUpdate], updatePassword);
router.get('/bookings', verifyToken, getBookingHistory);

module.exports = router; 