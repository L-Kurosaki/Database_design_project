const validateRegister = (req, res, next) => {
    const { email, password, firstName, lastName, phone } = req.body;

    if (!email || !password || !firstName || !lastName || !phone) {
        return res.status(400).json({
            success: false,
            message: 'All fields are required'
        });
    }

    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid email format'
        });
    }

    if (password.length < 6) {
        return res.status(400).json({
            success: false,
            message: 'Password must be at least 6 characters long'
        });
    }

    next();
};

const validateLogin = (req, res, next) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: 'Email and password are required'
        });
    }

    next();
};

const validateProfileUpdate = (req, res, next) => {
    const { firstName, lastName, phone, email } = req.body;

    if (!firstName || !lastName || !phone || !email) {
        return res.status(400).json({
            success: false,
            message: 'All fields are required'
        });
    }

    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid email format'
        });
    }

    next();
};

const validatePasswordUpdate = (req, res, next) => {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
        return res.status(400).json({
            success: false,
            message: 'Current password and new password are required'
        });
    }

    if (newPassword.length < 6) {
        return res.status(400).json({
            success: false,
            message: 'New password must be at least 6 characters long'
        });
    }

    next();
};

const validateScheduleSearch = (req, res, next) => {
    const { origin, destination, date } = req.query;

    if (!origin || !destination || !date) {
        return res.status(400).json({
            success: false,
            message: 'Origin, destination and date are required'
        });
    }

    next();
};

const validateBooking = (req, res, next) => {
    const { scheduleId, seats, passengers } = req.body;

    if (!scheduleId || !seats || !passengers) {
        return res.status(400).json({
            success: false,
            message: 'Schedule ID, seats and passenger details are required'
        });
    }

    if (!Array.isArray(seats) || seats.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'At least one seat must be selected'
        });
    }

    if (!Array.isArray(passengers) || passengers.length !== seats.length) {
        return res.status(400).json({
            success: false,
            message: 'Passenger details must match the number of seats'
        });
    }

    next();
};

const validateComplaint = (req, res, next) => {
    const { subject, description, bookingId } = req.body;

    if (!subject || !description) {
        return res.status(400).json({
            success: false,
            message: 'Subject and description are required'
        });
    }

    if (subject.length < 5) {
        return res.status(400).json({
            success: false,
            message: 'Subject must be at least 5 characters long'
        });
    }

    if (description.length < 20) {
        return res.status(400).json({
            success: false,
            message: 'Description must be at least 20 characters long'
        });
    }

    next();
};

module.exports = {
    validateRegister,
    validateLogin,
    validateProfileUpdate,
    validatePasswordUpdate,
    validateScheduleSearch,
    validateBooking,
    validateComplaint
}; 