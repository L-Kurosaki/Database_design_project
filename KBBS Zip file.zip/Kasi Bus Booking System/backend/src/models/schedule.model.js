const db = require('../config/db.config');

class Schedule {
    static async create(scheduleData) {
        const { 
            busId, 
            origin, 
            destination, 
            departureTime, 
            arrivalTime, 
            price,
            availableSeats 
        } = scheduleData;

        const [result] = await db.execute(
            `INSERT INTO schedules 
            (bus_id, origin, destination, departure_time, arrival_time, price, available_seats) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [busId, origin, destination, departureTime, arrivalTime, price, availableSeats]
        );

        return result.insertId;
    }

    static async findAll() {
        const [rows] = await db.execute(
            `SELECT s.*, b.name as bus_name, b.type as bus_type 
            FROM schedules s 
            JOIN buses b ON s.bus_id = b.id 
            WHERE s.departure_time > NOW()`
        );
        return rows;
    }

    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT s.*, b.name as bus_name, b.type as bus_type, b.total_seats 
            FROM schedules s 
            JOIN buses b ON s.bus_id = b.id 
            WHERE s.id = ?`,
            [id]
        );
        return rows[0];
    }

    static async search(criteria) {
        const { origin, destination, date } = criteria;
        
        const [rows] = await db.execute(
            `SELECT s.*, b.name as bus_name, b.type as bus_type 
            FROM schedules s 
            JOIN buses b ON s.bus_id = b.id 
            WHERE s.origin = ? 
            AND s.destination = ? 
            AND DATE(s.departure_time) = ?
            AND s.available_seats > 0
            AND s.departure_time > NOW()`,
            [origin, destination, date]
        );
        
        return rows;
    }

    static async updateAvailableSeats(id, seatCount, increment = false) {
        const operator = increment ? '+' : '-';
        const [result] = await db.execute(
            `UPDATE schedules 
            SET available_seats = available_seats ${operator} ? 
            WHERE id = ? AND available_seats ${increment ? '>= 0' : '>= ?'}`,
            increment ? [seatCount, id] : [seatCount, id, seatCount]
        );
        
        return result.affectedRows > 0;
    }

    static async getAvailableSeats(id) {
        const [rows] = await db.execute(
            `SELECT s.available_seats, b.total_seats,
            (SELECT GROUP_CONCAT(seat_number) 
             FROM bookings_seats 
             WHERE schedule_id = s.id) as booked_seats
            FROM schedules s
            JOIN buses b ON s.bus_id = b.id
            WHERE s.id = ?`,
            [id]
        );
        
        return rows[0];
    }
}

module.exports = Schedule; 