const db = require('../config/db.config');

class Booking {
    static async create(bookingData) {
        const { 
            userId, 
            scheduleId, 
            totalAmount,
            status = 'pending',
            passengers,
            seats 
        } = bookingData;

        // Start transaction
        const connection = await db.getConnection();
        await connection.beginTransaction();

        try {
            // Create booking
            const [bookingResult] = await connection.execute(
                `INSERT INTO bookings 
                (user_id, schedule_id, total_amount, status) 
                VALUES (?, ?, ?, ?)`,
                [userId, scheduleId, totalAmount, status]
            );
            
            const bookingId = bookingResult.insertId;

            // Add passengers
            for (const passenger of passengers) {
                await connection.execute(
                    `INSERT INTO booking_passengers 
                    (booking_id, name, id_number, phone) 
                    VALUES (?, ?, ?, ?)`,
                    [bookingId, passenger.name, passenger.idNumber, passenger.phone]
                );
            }

            // Add seats
            for (const seatNumber of seats) {
                await connection.execute(
                    `INSERT INTO booking_seats 
                    (booking_id, schedule_id, seat_number) 
                    VALUES (?, ?, ?)`,
                    [bookingId, scheduleId, seatNumber]
                );
            }

            // Update available seats
            await connection.execute(
                `UPDATE schedules 
                SET available_seats = available_seats - ? 
                WHERE id = ?`,
                [seats.length, scheduleId]
            );

            await connection.commit();
            return bookingId;
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT b.*, 
            s.origin, s.destination, s.departure_time, s.arrival_time,
            bs.bus_name, bs.type as bus_type
            FROM bookings b
            JOIN schedules s ON b.schedule_id = s.id
            JOIN buses bs ON s.bus_id = bs.id
            WHERE b.id = ?`,
            [id]
        );

        if (rows[0]) {
            // Get passengers
            const [passengers] = await db.execute(
                'SELECT * FROM booking_passengers WHERE booking_id = ?',
                [id]
            );

            // Get seats
            const [seats] = await db.execute(
                'SELECT seat_number FROM booking_seats WHERE booking_id = ?',
                [id]
            );

            return {
                ...rows[0],
                passengers,
                seats: seats.map(s => s.seat_number)
            };
        }

        return null;
    }

    static async findByUser(userId) {
        const [rows] = await db.execute(
            `SELECT b.*, 
            s.origin, s.destination, s.departure_time, s.arrival_time,
            bs.bus_name, bs.type as bus_type
            FROM bookings b
            JOIN schedules s ON b.schedule_id = s.id
            JOIN buses bs ON s.bus_id = bs.id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC`,
            [userId]
        );
        return rows;
    }

    static async updateStatus(id, status) {
        const [result] = await db.execute(
            'UPDATE bookings SET status = ? WHERE id = ?',
            [status, id]
        );
        return result.affectedRows > 0;
    }

    static async cancel(id) {
        const connection = await db.getConnection();
        await connection.beginTransaction();

        try {
            // Get booking details
            const [booking] = await connection.execute(
                'SELECT schedule_id FROM bookings WHERE id = ?',
                [id]
            );

            if (!booking[0]) throw new Error('Booking not found');

            // Get number of seats
            const [seats] = await connection.execute(
                'SELECT COUNT(*) as count FROM booking_seats WHERE booking_id = ?',
                [id]
            );

            // Update booking status
            await connection.execute(
                'UPDATE bookings SET status = ? WHERE id = ?',
                ['cancelled', id]
            );

            // Return seats to available pool
            await connection.execute(
                `UPDATE schedules 
                SET available_seats = available_seats + ? 
                WHERE id = ?`,
                [seats[0].count, booking[0].schedule_id]
            );

            await connection.commit();
            return true;
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }
}

module.exports = Booking; 