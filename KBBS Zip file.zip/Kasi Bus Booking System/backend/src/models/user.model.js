const db = require('../config/db.config');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');

class User {
    static async create(userData) {
        const { firstName, lastName, email, password, phoneNumber, nextOfKin, role } = userData;
        const hashedPassword = await bcrypt.hash(password, 10);
        const id = uuidv4();

        const [result] = await db.execute(
            'INSERT INTO users (id, first_name, last_name, email, password, phone_number, next_of_kin, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [id, firstName, lastName, email, hashedPassword, phoneNumber, nextOfKin, role || 'PASSENGER']
        );

        return { id, ...userData };
    }

    static async findByEmail(email) {
        const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
        return rows[0];
    }

    static async findById(id) {
        const [rows] = await db.execute('SELECT * FROM users WHERE id = ?', [id]);
        return rows[0];
    }

    static async update(id, userData) {
        const { firstName, lastName, phoneNumber, nextOfKin } = userData;
        
        const [result] = await db.execute(
            'UPDATE users SET first_name = ?, last_name = ?, phone_number = ?, next_of_kin = ? WHERE id = ?',
            [firstName, lastName, phoneNumber, nextOfKin, id]
        );

        return result.affectedRows > 0;
    }

    static async delete(id) {
        const [result] = await db.execute('DELETE FROM users WHERE id = ?', [id]);
        return result.affectedRows > 0;
    }
}

module.exports = User; 