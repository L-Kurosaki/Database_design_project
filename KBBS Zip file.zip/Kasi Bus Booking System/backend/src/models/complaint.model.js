const db = require('../config/db.config');

class Complaint {
    static async create(complaintData) {
        const { 
            userId, 
            bookingId, 
            subject, 
            description, 
            status = 'pending' 
        } = complaintData;

        const [result] = await db.execute(
            `INSERT INTO complaints 
            (user_id, booking_id, subject, description, status) 
            VALUES (?, ?, ?, ?, ?)`,
            [userId, bookingId, subject, description, status]
        );

        return result.insertId;
    }

    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT c.*, 
            u.first_name, u.last_name, u.email,
            b.id as booking_reference
            FROM complaints c
            JOIN users u ON c.user_id = u.id
            LEFT JOIN bookings b ON c.booking_id = b.id
            WHERE c.id = ?`,
            [id]
        );

        if (rows[0]) {
            // Get responses
            const [responses] = await db.execute(
                `SELECT cr.*, u.first_name, u.last_name 
                FROM complaint_responses cr
                JOIN users u ON cr.admin_id = u.id
                WHERE cr.complaint_id = ?
                ORDER BY cr.created_at ASC`,
                [id]
            );

            return {
                ...rows[0],
                responses
            };
        }

        return null;
    }

    static async findByUser(userId) {
        const [rows] = await db.execute(
            `SELECT c.*, 
            b.id as booking_reference,
            (SELECT COUNT(*) FROM complaint_responses WHERE complaint_id = c.id) as response_count
            FROM complaints c
            LEFT JOIN bookings b ON c.booking_id = b.id
            WHERE c.user_id = ?
            ORDER BY c.created_at DESC`,
            [userId]
        );
        return rows;
    }

    static async updateStatus(id, status) {
        const [result] = await db.execute(
            'UPDATE complaints SET status = ? WHERE id = ?',
            [status, id]
        );
        return result.affectedRows > 0;
    }

    static async addResponse(responseData) {
        const { complaintId, adminId, response } = responseData;

        const [result] = await db.execute(
            `INSERT INTO complaint_responses 
            (complaint_id, admin_id, response) 
            VALUES (?, ?, ?)`,
            [complaintId, adminId, response]
        );

        // Update complaint status to 'responded'
        await db.execute(
            'UPDATE complaints SET status = ? WHERE id = ?',
            ['responded', complaintId]
        );

        return result.insertId;
    }

    static async getStats() {
        const [rows] = await db.execute(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'responded' THEN 1 ELSE 0 END) as responded,
                SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved
            FROM complaints
        `);
        return rows[0];
    }
}

module.exports = Complaint; 