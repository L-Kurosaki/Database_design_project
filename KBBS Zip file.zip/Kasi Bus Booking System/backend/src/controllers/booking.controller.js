const Booking = require('../models/booking.model');
const Schedule = require('../models/schedule.model');

// Create a new booking
exports.createBooking = async (req, res) => {
    try {
        const { scheduleId, passengers, seats, totalAmount } = req.body;
        const userId = req.user.id;

        // Check if schedule exists and has enough seats
        const schedule = await Schedule.findById(scheduleId);
        if (!schedule) {
            return res.status(404).json({
                success: false,
                message: 'Schedule not found'
            });
        }

        if (schedule.available_seats < seats.length) {
            return res.status(400).json({
                success: false,
                message: 'Not enough seats available'
            });
        }

        // Create booking
        const bookingId = await Booking.create({
            userId,
            scheduleId,
            totalAmount,
            passengers,
            seats,
            status: 'pending'
        });

        const booking = await Booking.findById(bookingId);
        
        res.status(201).json({
            success: true,
            message: 'Booking created successfully',
            data: booking
        });
    } catch (error) {
        console.error('Error creating booking:', error);
        res.status(500).json({
            success: false,
            message: 'Error creating booking',
            error: error.message
        });
    }
};

// Get booking by ID
exports.getBookingById = async (req, res) => {
    try {
        const { id } = req.params;
        const booking = await Booking.findById(id);

        if (!booking) {
            return res.status(404).json({
                success: false,
                message: 'Booking not found'
            });
        }

        // Check if user is authorized to view this booking
        if (booking.user_id !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to view this booking'
            });
        }

        res.json({
            success: true,
            data: booking
        });
    } catch (error) {
        console.error('Error fetching booking:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching booking',
            error: error.message
        });
    }
};

// Cancel booking
exports.cancelBooking = async (req, res) => {
    try {
        const { id } = req.params;
        const booking = await Booking.findById(id);

        if (!booking) {
            return res.status(404).json({
                success: false,
                message: 'Booking not found'
            });
        }

        // Check if user is authorized to cancel this booking
        if (booking.user_id !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to cancel this booking'
            });
        }

        // Check if booking can be cancelled
        if (booking.status === 'cancelled') {
            return res.status(400).json({
                success: false,
                message: 'Booking is already cancelled'
            });
        }

        const success = await Booking.cancel(id);
        if (!success) {
            throw new Error('Failed to cancel booking');
        }

        res.json({
            success: true,
            message: 'Booking cancelled successfully'
        });
    } catch (error) {
        console.error('Error cancelling booking:', error);
        res.status(500).json({
            success: false,
            message: 'Error cancelling booking',
            error: error.message
        });
    }
};

// Confirm payment
exports.confirmPayment = async (req, res) => {
    try {
        const { id } = req.params;
        const { paymentMethod, transactionId } = req.body;

        const booking = await Booking.findById(id);
        if (!booking) {
            return res.status(404).json({
                success: false,
                message: 'Booking not found'
            });
        }

        // Check if user is authorized
        if (booking.user_id !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to confirm payment'
            });
        }

        // Update booking status
        await Booking.updateStatus(id, 'confirmed');

        // Create payment record (assuming you have a Payment model)
        // await Payment.create({
        //     bookingId: id,
        //     amount: booking.total_amount,
        //     paymentMethod,
        //     transactionId,
        //     status: 'completed'
        // });

        res.json({
            success: true,
            message: 'Payment confirmed successfully'
        });
    } catch (error) {
        console.error('Error confirming payment:', error);
        res.status(500).json({
            success: false,
            message: 'Error confirming payment',
            error: error.message
        });
    }
};

// Get booking history for a user
exports.getBookingHistory = async (req, res) => {
    try {
        const { userId } = req.params;

        // Check if user is authorized
        if (userId !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to view booking history'
            });
        }

        const bookings = await Booking.findByUser(userId);
        
        res.json({
            success: true,
            data: bookings
        });
    } catch (error) {
        console.error('Error fetching booking history:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching booking history',
            error: error.message
        });
    }
}; 