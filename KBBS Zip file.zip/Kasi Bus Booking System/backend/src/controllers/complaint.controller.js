const Complaint = require('../models/complaint.model');

// Create a new complaint
exports.createComplaint = async (req, res) => {
    try {
        const { bookingId, subject, description } = req.body;
        const userId = req.user.id;

        const complaintId = await Complaint.create({
            userId,
            bookingId,
            subject,
            description
        });

        const complaint = await Complaint.findById(complaintId);
        
        res.status(201).json({
            success: true,
            message: 'Complaint submitted successfully',
            data: complaint
        });
    } catch (error) {
        console.error('Error creating complaint:', error);
        res.status(500).json({
            success: false,
            message: 'Error submitting complaint',
            error: error.message
        });
    }
};

// Get complaint by ID
exports.getComplaintById = async (req, res) => {
    try {
        const { id } = req.params;
        const complaint = await Complaint.findById(id);

        if (!complaint) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        // Check if user is authorized to view this complaint
        if (complaint.user_id !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to view this complaint'
            });
        }

        res.json({
            success: true,
            data: complaint
        });
    } catch (error) {
        console.error('Error fetching complaint:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching complaint',
            error: error.message
        });
    }
};

// Get user's complaints
exports.getUserComplaints = async (req, res) => {
    try {
        const userId = req.user.id;
        const complaints = await Complaint.findByUser(userId);
        
        res.json({
            success: true,
            data: complaints
        });
    } catch (error) {
        console.error('Error fetching complaints:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching complaints',
            error: error.message
        });
    }
};

// Add response to complaint (admin only)
exports.addResponse = async (req, res) => {
    try {
        const { id } = req.params;
        const { response } = req.body;
        const adminId = req.user.id;

        // Check if user is admin
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Only administrators can respond to complaints'
            });
        }

        const responseId = await Complaint.addResponse({
            complaintId: id,
            adminId,
            response
        });

        res.json({
            success: true,
            message: 'Response added successfully',
            data: { responseId }
        });
    } catch (error) {
        console.error('Error adding response:', error);
        res.status(500).json({
            success: false,
            message: 'Error adding response',
            error: error.message
        });
    }
};

// Update complaint status
exports.updateStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        // Check if user is admin
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Only administrators can update complaint status'
            });
        }

        // Validate status
        const validStatuses = ['pending', 'responded', 'resolved'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid status value'
            });
        }

        const success = await Complaint.updateStatus(id, status);
        if (!success) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        res.json({
            success: true,
            message: 'Complaint status updated successfully'
        });
    } catch (error) {
        console.error('Error updating complaint status:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating complaint status',
            error: error.message
        });
    }
};

// Get complaint statistics (admin only)
exports.getStats = async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Only administrators can view complaint statistics'
            });
        }

        const stats = await Complaint.getStats();
        
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Error fetching complaint statistics:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching complaint statistics',
            error: error.message
        });
    }
}; 