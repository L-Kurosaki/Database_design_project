const Schedule = require('../models/schedule.model');

// Create a new schedule
exports.createSchedule = async (req, res) => {
    try {
        const { 
            busId, 
            origin, 
            destination, 
            departureTime, 
            arrivalTime, 
            price,
            availableSeats 
        } = req.body;

        // Only admin can create schedules
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to create schedules'
            });
        }

        const scheduleId = await Schedule.create({
            busId,
            origin,
            destination,
            departureTime,
            arrivalTime,
            price,
            availableSeats
        });

        const schedule = await Schedule.findById(scheduleId);
        
        res.status(201).json({
            success: true,
            message: 'Schedule created successfully',
            data: schedule
        });
    } catch (error) {
        console.error('Error creating schedule:', error);
        res.status(500).json({
            success: false,
            message: 'Error creating schedule',
            error: error.message
        });
    }
};

// Get all schedules
exports.getAllSchedules = async (req, res) => {
    try {
        const schedules = await Schedule.findAll();
        
        res.json({
            success: true,
            data: schedules
        });
    } catch (error) {
        console.error('Error fetching schedules:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching schedules',
            error: error.message
        });
    }
};

// Get schedule by ID
exports.getScheduleById = async (req, res) => {
    try {
        const { id } = req.params;
        const schedule = await Schedule.findById(id);

        if (!schedule) {
            return res.status(404).json({
                success: false,
                message: 'Schedule not found'
            });
        }

        res.json({
            success: true,
            data: schedule
        });
    } catch (error) {
        console.error('Error fetching schedule:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching schedule',
            error: error.message
        });
    }
};

// Search schedules
exports.searchSchedules = async (req, res) => {
    try {
        const { origin, destination, date } = req.query;

        if (!origin || !destination || !date) {
            return res.status(400).json({
                success: false,
                message: 'Origin, destination and date are required'
            });
        }

        const schedules = await Schedule.search({
            origin,
            destination,
            date
        });

        res.json({
            success: true,
            data: schedules
        });
    } catch (error) {
        console.error('Error searching schedules:', error);
        res.status(500).json({
            success: false,
            message: 'Error searching schedules',
            error: error.message
        });
    }
};

// Get available seats for a schedule
exports.getAvailableSeats = async (req, res) => {
    try {
        const { id } = req.params;
        const seatInfo = await Schedule.getAvailableSeats(id);

        if (!seatInfo) {
            return res.status(404).json({
                success: false,
                message: 'Schedule not found'
            });
        }

        // Parse booked seats string into array
        const bookedSeats = seatInfo.booked_seats ? 
            seatInfo.booked_seats.split(',') : 
            [];

        res.json({
            success: true,
            data: {
                availableSeats: seatInfo.available_seats,
                totalSeats: seatInfo.total_seats,
                bookedSeats
            }
        });
    } catch (error) {
        console.error('Error fetching seat information:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching seat information',
            error: error.message
        });
    }
}; 